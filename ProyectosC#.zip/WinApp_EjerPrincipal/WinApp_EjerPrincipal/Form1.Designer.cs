﻿namespace WinApp_EjerPrincipal
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.inicioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estructuraSecuencialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cantidadDeCifrasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.distanciaEntre2PuntosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pendienteDeUnaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.áreaDeUnTerrenoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculadoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estructuraRepetitivaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tresLongitudesTriánguloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clasificaciónCircunferenciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.siguienteSegundoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.libreríaRandomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.escToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calcularRestoYCocienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pagoDeEmpresaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.serieFibonacciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calcularSerieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.matrizValoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventasEmpresaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editorDeTextoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.númeroEnCadenaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.candidatosPresidenteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.anexoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(694, 411);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 27);
            this.button1.TabIndex = 0;
            this.button1.Text = "Salir";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 380);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "Estudiante de Ingenierìa en Software";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(483, 342);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Ing. Lorena Aguirre";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(492, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "Patricio Quishpe";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 93);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inicioToolStripMenuItem,
            this.estructuraSecuencialToolStripMenuItem,
            this.estructuraRepetitivaToolStripMenuItem,
            this.escToolStripMenuItem,
            this.otrosToolStripMenuItem,
            this.ayudaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // inicioToolStripMenuItem
            // 
            this.inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            this.inicioToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.inicioToolStripMenuItem.Text = "Inicio";
            // 
            // estructuraSecuencialToolStripMenuItem
            // 
            this.estructuraSecuencialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cantidadDeCifrasToolStripMenuItem,
            this.distanciaEntre2PuntosToolStripMenuItem,
            this.pendienteDeUnaToolStripMenuItem,
            this.áreaDeUnTerrenoToolStripMenuItem,
            this.calculadoraToolStripMenuItem});
            this.estructuraSecuencialToolStripMenuItem.Name = "estructuraSecuencialToolStripMenuItem";
            this.estructuraSecuencialToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.estructuraSecuencialToolStripMenuItem.Text = "Estruc. Secuencial";
            // 
            // cantidadDeCifrasToolStripMenuItem
            // 
            this.cantidadDeCifrasToolStripMenuItem.Name = "cantidadDeCifrasToolStripMenuItem";
            this.cantidadDeCifrasToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.cantidadDeCifrasToolStripMenuItem.Text = "1. Cantidad de Cifras";
            this.cantidadDeCifrasToolStripMenuItem.Click += new System.EventHandler(this.cantidadDeCifrasToolStripMenuItem_Click);
            // 
            // distanciaEntre2PuntosToolStripMenuItem
            // 
            this.distanciaEntre2PuntosToolStripMenuItem.Name = "distanciaEntre2PuntosToolStripMenuItem";
            this.distanciaEntre2PuntosToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.distanciaEntre2PuntosToolStripMenuItem.Text = "2. Distancia entre 2 puntos";
            this.distanciaEntre2PuntosToolStripMenuItem.Click += new System.EventHandler(this.distanciaEntre2PuntosToolStripMenuItem_Click);
            // 
            // pendienteDeUnaToolStripMenuItem
            // 
            this.pendienteDeUnaToolStripMenuItem.Name = "pendienteDeUnaToolStripMenuItem";
            this.pendienteDeUnaToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.pendienteDeUnaToolStripMenuItem.Text = "3. Pendiente de una recta";
            // 
            // áreaDeUnTerrenoToolStripMenuItem
            // 
            this.áreaDeUnTerrenoToolStripMenuItem.Name = "áreaDeUnTerrenoToolStripMenuItem";
            this.áreaDeUnTerrenoToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.áreaDeUnTerrenoToolStripMenuItem.Text = "4. Área de un terreno";
            // 
            // calculadoraToolStripMenuItem
            // 
            this.calculadoraToolStripMenuItem.Name = "calculadoraToolStripMenuItem";
            this.calculadoraToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.calculadoraToolStripMenuItem.Text = "5. Calculadora";
            // 
            // estructuraRepetitivaToolStripMenuItem
            // 
            this.estructuraRepetitivaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tresLongitudesTriánguloToolStripMenuItem,
            this.clasificaciónCircunferenciaToolStripMenuItem,
            this.toolStripMenuItem2,
            this.siguienteSegundoToolStripMenuItem,
            this.libreríaRandomToolStripMenuItem,
            this.toolStripMenuItem3});
            this.estructuraRepetitivaToolStripMenuItem.Name = "estructuraRepetitivaToolStripMenuItem";
            this.estructuraRepetitivaToolStripMenuItem.Size = new System.Drawing.Size(116, 20);
            this.estructuraRepetitivaToolStripMenuItem.Text = "Estruc Alternativas";
            this.estructuraRepetitivaToolStripMenuItem.Click += new System.EventHandler(this.estructuraRepetitivaToolStripMenuItem_Click);
            // 
            // tresLongitudesTriánguloToolStripMenuItem
            // 
            this.tresLongitudesTriánguloToolStripMenuItem.Name = "tresLongitudesTriánguloToolStripMenuItem";
            this.tresLongitudesTriánguloToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.tresLongitudesTriánguloToolStripMenuItem.Text = "6. Tres longitudes (Triángulo)";
            // 
            // clasificaciónCircunferenciaToolStripMenuItem
            // 
            this.clasificaciónCircunferenciaToolStripMenuItem.Name = "clasificaciónCircunferenciaToolStripMenuItem";
            this.clasificaciónCircunferenciaToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.clasificaciónCircunferenciaToolStripMenuItem.Text = "7. Clasificación circunferencia";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(231, 22);
            this.toolStripMenuItem2.Text = "8. Identificar cuadrante";
            // 
            // siguienteSegundoToolStripMenuItem
            // 
            this.siguienteSegundoToolStripMenuItem.Name = "siguienteSegundoToolStripMenuItem";
            this.siguienteSegundoToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.siguienteSegundoToolStripMenuItem.Text = "9. Siguiente segundo";
            // 
            // libreríaRandomToolStripMenuItem
            // 
            this.libreríaRandomToolStripMenuItem.Name = "libreríaRandomToolStripMenuItem";
            this.libreríaRandomToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.libreríaRandomToolStripMenuItem.Text = "10. Librería random";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(231, 22);
            this.toolStripMenuItem3.Text = "11. Compra interactiva";
            // 
            // escToolStripMenuItem
            // 
            this.escToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calcularRestoYCocienteToolStripMenuItem,
            this.pagoDeEmpresaToolStripMenuItem,
            this.serieFibonacciToolStripMenuItem,
            this.calcularSerieToolStripMenuItem,
            this.matrizValoresToolStripMenuItem,
            this.ventasEmpresaToolStripMenuItem});
            this.escToolStripMenuItem.Name = "escToolStripMenuItem";
            this.escToolStripMenuItem.Size = new System.Drawing.Size(111, 20);
            this.escToolStripMenuItem.Text = "Estruc Repetitivas";
            // 
            // calcularRestoYCocienteToolStripMenuItem
            // 
            this.calcularRestoYCocienteToolStripMenuItem.Name = "calcularRestoYCocienteToolStripMenuItem";
            this.calcularRestoYCocienteToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.calcularRestoYCocienteToolStripMenuItem.Text = "12. Calcular resto y cociente";
            // 
            // pagoDeEmpresaToolStripMenuItem
            // 
            this.pagoDeEmpresaToolStripMenuItem.Name = "pagoDeEmpresaToolStripMenuItem";
            this.pagoDeEmpresaToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.pagoDeEmpresaToolStripMenuItem.Text = "13. Pago de empresa";
            // 
            // serieFibonacciToolStripMenuItem
            // 
            this.serieFibonacciToolStripMenuItem.Name = "serieFibonacciToolStripMenuItem";
            this.serieFibonacciToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.serieFibonacciToolStripMenuItem.Text = "14. Serie fibonacci";
            // 
            // calcularSerieToolStripMenuItem
            // 
            this.calcularSerieToolStripMenuItem.Name = "calcularSerieToolStripMenuItem";
            this.calcularSerieToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.calcularSerieToolStripMenuItem.Text = "15. Calcular serie";
            // 
            // matrizValoresToolStripMenuItem
            // 
            this.matrizValoresToolStripMenuItem.Name = "matrizValoresToolStripMenuItem";
            this.matrizValoresToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.matrizValoresToolStripMenuItem.Text = "16. Matriz valores";
            // 
            // ventasEmpresaToolStripMenuItem
            // 
            this.ventasEmpresaToolStripMenuItem.Name = "ventasEmpresaToolStripMenuItem";
            this.ventasEmpresaToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.ventasEmpresaToolStripMenuItem.Text = "17. Ventas empresa";
            // 
            // otrosToolStripMenuItem
            // 
            this.otrosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editorDeTextoToolStripMenuItem,
            this.númeroEnCadenaToolStripMenuItem,
            this.candidatosPresidenteToolStripMenuItem});
            this.otrosToolStripMenuItem.Name = "otrosToolStripMenuItem";
            this.otrosToolStripMenuItem.Size = new System.Drawing.Size(108, 20);
            this.otrosToolStripMenuItem.Text = "Otros Programas";
            // 
            // editorDeTextoToolStripMenuItem
            // 
            this.editorDeTextoToolStripMenuItem.Name = "editorDeTextoToolStripMenuItem";
            this.editorDeTextoToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.editorDeTextoToolStripMenuItem.Text = "18. Editor de texto";
            // 
            // númeroEnCadenaToolStripMenuItem
            // 
            this.númeroEnCadenaToolStripMenuItem.Name = "númeroEnCadenaToolStripMenuItem";
            this.númeroEnCadenaToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.númeroEnCadenaToolStripMenuItem.Text = "19. Número en cadena";
            // 
            // candidatosPresidenteToolStripMenuItem
            // 
            this.candidatosPresidenteToolStripMenuItem.Name = "candidatosPresidenteToolStripMenuItem";
            this.candidatosPresidenteToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.candidatosPresidenteToolStripMenuItem.Text = "20. Candidatos presidente";
            // 
            // ayudaToolStripMenuItem
            // 
            this.ayudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.anexoToolStripMenuItem});
            this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            this.ayudaToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.ayudaToolStripMenuItem.Text = "Ayuda";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(281, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(246, 22);
            this.label3.TabIndex = 10;
            this.label3.Text = "Aplicaciones Informàticas";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(534, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 18);
            this.label5.TabIndex = 11;
            this.label5.Text = "7364";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(132, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(590, 32);
            this.label6.TabIndex = 12;
            this.label6.Text = "Escuela Superior Politèctica de Chimborazo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(363, 231);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 18);
            this.label7.TabIndex = 13;
            this.label7.Text = "Còdigo:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(351, 270);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 18);
            this.label8.TabIndex = 14;
            this.label8.Text = "Teléfono:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(351, 191);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 18);
            this.label9.TabIndex = 15;
            this.label9.Text = "Nombre:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(504, 270);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 18);
            this.label11.TabIndex = 17;
            this.label11.Text = "0981781209";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(466, 307);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(272, 18);
            this.label12.TabIndex = 18;
            this.label12.Text = "patricio.quishpe@espoch.edu.ec";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(336, 307);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 18);
            this.label13.TabIndex = 19;
            this.label13.Text = "Correo Elec.:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(351, 342);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 18);
            this.label14.TabIndex = 20;
            this.label14.Text = "Docente:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(104, 164);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(152, 179);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // anexoToolStripMenuItem
            // 
            this.anexoToolStripMenuItem.Name = "anexoToolStripMenuItem";
            this.anexoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.anexoToolStripMenuItem.Text = "Anexo";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "x";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem inicioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estructuraSecuencialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estructuraRepetitivaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem escToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ToolStripMenuItem cantidadDeCifrasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem distanciaEntre2PuntosToolStripMenuItem;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ToolStripMenuItem pendienteDeUnaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem áreaDeUnTerrenoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculadoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tresLongitudesTriánguloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clasificaciónCircunferenciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem siguienteSegundoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem libreríaRandomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem calcularRestoYCocienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pagoDeEmpresaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serieFibonacciToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calcularSerieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem matrizValoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventasEmpresaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editorDeTextoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem númeroEnCadenaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem candidatosPresidenteToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolStripMenuItem anexoToolStripMenuItem;
    }
}

