﻿namespace Calculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn1 = new System.Windows.Forms.Button();
            this.Btn6 = new System.Windows.Forms.Button();
            this.BtnResta = new System.Windows.Forms.Button();
            this.Btn9 = new System.Windows.Forms.Button();
            this.BtnDivision = new System.Windows.Forms.Button();
            this.BtnMultiplicacion = new System.Windows.Forms.Button();
            this.Btn0 = new System.Windows.Forms.Button();
            this.Btn2 = new System.Windows.Forms.Button();
            this.Btn7 = new System.Windows.Forms.Button();
            this.Btn3 = new System.Windows.Forms.Button();
            this.Btn8 = new System.Windows.Forms.Button();
            this.Btn5 = new System.Windows.Forms.Button();
            this.Btn4 = new System.Windows.Forms.Button();
            this.BtnSuma = new System.Windows.Forms.Button();
            this.BtnIgual = new System.Windows.Forms.Button();
            this.BtnPotencia = new System.Windows.Forms.Button();
            this.BtnTangente = new System.Windows.Forms.Button();
            this.BtnCos = new System.Windows.Forms.Button();
            this.BtnLog = new System.Windows.Forms.Button();
            this.BtnRaiz = new System.Windows.Forms.Button();
            this.BtnSeno = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.LblRespuesta = new System.Windows.Forms.Label();
            this.TxtPantalla = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnSalir = new System.Windows.Forms.Button();
            this.BtnPunto = new System.Windows.Forms.Button();
            this.BtnLimpiar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Btn1
            // 
            this.Btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn1.Location = new System.Drawing.Point(73, 255);
            this.Btn1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(28, 29);
            this.Btn1.TabIndex = 0;
            this.Btn1.Text = "1";
            this.Btn1.UseVisualStyleBackColor = true;
            this.Btn1.Click += new System.EventHandler(this.Btn4_Click_1);
            // 
            // Btn6
            // 
            this.Btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn6.Location = new System.Drawing.Point(187, 209);
            this.Btn6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn6.Name = "Btn6";
            this.Btn6.Size = new System.Drawing.Size(28, 28);
            this.Btn6.TabIndex = 1;
            this.Btn6.Text = "6";
            this.Btn6.UseVisualStyleBackColor = true;
            this.Btn6.Click += new System.EventHandler(this.Btn4_Click_1);
            // 
            // BtnResta
            // 
            this.BtnResta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnResta.Location = new System.Drawing.Point(309, 162);
            this.BtnResta.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnResta.Name = "BtnResta";
            this.BtnResta.Size = new System.Drawing.Size(28, 28);
            this.BtnResta.TabIndex = 2;
            this.BtnResta.Text = "-";
            this.BtnResta.UseVisualStyleBackColor = true;
            this.BtnResta.Click += new System.EventHandler(this.BtnSeno_Click);
            // 
            // Btn9
            // 
            this.Btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn9.Location = new System.Drawing.Point(187, 162);
            this.Btn9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn9.Name = "Btn9";
            this.Btn9.Size = new System.Drawing.Size(28, 28);
            this.Btn9.TabIndex = 3;
            this.Btn9.Text = "9";
            this.Btn9.UseVisualStyleBackColor = true;
            this.Btn9.Click += new System.EventHandler(this.Btn4_Click_1);
            // 
            // BtnDivision
            // 
            this.BtnDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDivision.Location = new System.Drawing.Point(309, 209);
            this.BtnDivision.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnDivision.Name = "BtnDivision";
            this.BtnDivision.Size = new System.Drawing.Size(28, 28);
            this.BtnDivision.TabIndex = 4;
            this.BtnDivision.Text = "/";
            this.BtnDivision.UseVisualStyleBackColor = true;
            this.BtnDivision.Click += new System.EventHandler(this.BtnSeno_Click);
            // 
            // BtnMultiplicacion
            // 
            this.BtnMultiplicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMultiplicacion.Location = new System.Drawing.Point(266, 209);
            this.BtnMultiplicacion.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnMultiplicacion.Name = "BtnMultiplicacion";
            this.BtnMultiplicacion.Size = new System.Drawing.Size(25, 28);
            this.BtnMultiplicacion.TabIndex = 5;
            this.BtnMultiplicacion.Text = "*";
            this.BtnMultiplicacion.UseVisualStyleBackColor = true;
            this.BtnMultiplicacion.Click += new System.EventHandler(this.BtnSeno_Click);
            // 
            // Btn0
            // 
            this.Btn0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn0.Location = new System.Drawing.Point(134, 311);
            this.Btn0.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn0.Name = "Btn0";
            this.Btn0.Size = new System.Drawing.Size(28, 30);
            this.Btn0.TabIndex = 6;
            this.Btn0.Text = "0";
            this.Btn0.UseVisualStyleBackColor = true;
            this.Btn0.Click += new System.EventHandler(this.Btn4_Click_1);
            // 
            // Btn2
            // 
            this.Btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn2.Location = new System.Drawing.Point(134, 255);
            this.Btn2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(28, 29);
            this.Btn2.TabIndex = 7;
            this.Btn2.Text = "2";
            this.Btn2.UseVisualStyleBackColor = true;
            this.Btn2.Click += new System.EventHandler(this.Btn4_Click_1);
            // 
            // Btn7
            // 
            this.Btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn7.Location = new System.Drawing.Point(73, 162);
            this.Btn7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn7.Name = "Btn7";
            this.Btn7.Size = new System.Drawing.Size(28, 28);
            this.Btn7.TabIndex = 8;
            this.Btn7.Text = "7";
            this.Btn7.UseVisualStyleBackColor = true;
            this.Btn7.Click += new System.EventHandler(this.Btn4_Click_1);
            // 
            // Btn3
            // 
            this.Btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn3.Location = new System.Drawing.Point(187, 255);
            this.Btn3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(28, 29);
            this.Btn3.TabIndex = 9;
            this.Btn3.Text = "3";
            this.Btn3.UseVisualStyleBackColor = true;
            this.Btn3.Click += new System.EventHandler(this.Btn4_Click_1);
            // 
            // Btn8
            // 
            this.Btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn8.Location = new System.Drawing.Point(134, 162);
            this.Btn8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn8.Name = "Btn8";
            this.Btn8.Size = new System.Drawing.Size(28, 28);
            this.Btn8.TabIndex = 10;
            this.Btn8.Text = "8";
            this.Btn8.UseVisualStyleBackColor = true;
            this.Btn8.Click += new System.EventHandler(this.Btn4_Click_1);
            // 
            // Btn5
            // 
            this.Btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn5.Location = new System.Drawing.Point(134, 209);
            this.Btn5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn5.Name = "Btn5";
            this.Btn5.Size = new System.Drawing.Size(28, 28);
            this.Btn5.TabIndex = 11;
            this.Btn5.Text = "5";
            this.Btn5.UseVisualStyleBackColor = true;
            this.Btn5.Click += new System.EventHandler(this.Btn4_Click_1);
            // 
            // Btn4
            // 
            this.Btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn4.Location = new System.Drawing.Point(73, 209);
            this.Btn4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Btn4.Name = "Btn4";
            this.Btn4.Size = new System.Drawing.Size(28, 28);
            this.Btn4.TabIndex = 12;
            this.Btn4.Text = "4";
            this.Btn4.UseVisualStyleBackColor = true;
            this.Btn4.Click += new System.EventHandler(this.Btn4_Click_1);
            // 
            // BtnSuma
            // 
            this.BtnSuma.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSuma.Location = new System.Drawing.Point(266, 162);
            this.BtnSuma.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnSuma.Name = "BtnSuma";
            this.BtnSuma.Size = new System.Drawing.Size(25, 28);
            this.BtnSuma.TabIndex = 13;
            this.BtnSuma.Text = "+";
            this.BtnSuma.UseVisualStyleBackColor = true;
            this.BtnSuma.Click += new System.EventHandler(this.BtnSeno_Click);
            // 
            // BtnIgual
            // 
            this.BtnIgual.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnIgual.Location = new System.Drawing.Point(187, 311);
            this.BtnIgual.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnIgual.Name = "BtnIgual";
            this.BtnIgual.Size = new System.Drawing.Size(28, 30);
            this.BtnIgual.TabIndex = 14;
            this.BtnIgual.Text = "=";
            this.BtnIgual.UseVisualStyleBackColor = true;
            this.BtnIgual.Click += new System.EventHandler(this.BtnIgual_Click_1);
            // 
            // BtnPotencia
            // 
            this.BtnPotencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPotencia.Location = new System.Drawing.Point(266, 255);
            this.BtnPotencia.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnPotencia.Name = "BtnPotencia";
            this.BtnPotencia.Size = new System.Drawing.Size(25, 29);
            this.BtnPotencia.TabIndex = 15;
            this.BtnPotencia.Text = "^";
            this.BtnPotencia.UseVisualStyleBackColor = true;
            this.BtnPotencia.Click += new System.EventHandler(this.BtnSeno_Click);
            // 
            // BtnTangente
            // 
            this.BtnTangente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTangente.Location = new System.Drawing.Point(365, 255);
            this.BtnTangente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnTangente.Name = "BtnTangente";
            this.BtnTangente.Size = new System.Drawing.Size(50, 29);
            this.BtnTangente.TabIndex = 16;
            this.BtnTangente.Text = "Tan";
            this.BtnTangente.UseVisualStyleBackColor = true;
            this.BtnTangente.Click += new System.EventHandler(this.BtnSeno_Click);
            // 
            // BtnCos
            // 
            this.BtnCos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCos.Location = new System.Drawing.Point(443, 162);
            this.BtnCos.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnCos.Name = "BtnCos";
            this.BtnCos.Size = new System.Drawing.Size(49, 28);
            this.BtnCos.TabIndex = 17;
            this.BtnCos.Text = "Cos";
            this.BtnCos.UseVisualStyleBackColor = true;
            this.BtnCos.Click += new System.EventHandler(this.BtnSeno_Click);
            // 
            // BtnLog
            // 
            this.BtnLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLog.Location = new System.Drawing.Point(365, 162);
            this.BtnLog.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnLog.Name = "BtnLog";
            this.BtnLog.Size = new System.Drawing.Size(50, 28);
            this.BtnLog.TabIndex = 18;
            this.BtnLog.Text = "Log";
            this.BtnLog.UseVisualStyleBackColor = true;
            this.BtnLog.Click += new System.EventHandler(this.BtnSeno_Click);
            // 
            // BtnRaiz
            // 
            this.BtnRaiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRaiz.Location = new System.Drawing.Point(309, 255);
            this.BtnRaiz.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnRaiz.Name = "BtnRaiz";
            this.BtnRaiz.Size = new System.Drawing.Size(28, 29);
            this.BtnRaiz.TabIndex = 19;
            this.BtnRaiz.Text = "√";
            this.BtnRaiz.UseVisualStyleBackColor = true;
            this.BtnRaiz.Click += new System.EventHandler(this.BtnSeno_Click);
            // 
            // BtnSeno
            // 
            this.BtnSeno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSeno.Location = new System.Drawing.Point(365, 209);
            this.BtnSeno.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnSeno.Name = "BtnSeno";
            this.BtnSeno.Size = new System.Drawing.Size(50, 28);
            this.BtnSeno.TabIndex = 20;
            this.BtnSeno.Text = "Sen";
            this.BtnSeno.UseVisualStyleBackColor = true;
            this.BtnSeno.Click += new System.EventHandler(this.BtnSeno_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(94, 117);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "La respuesta es:";
            // 
            // LblRespuesta
            // 
            this.LblRespuesta.AutoSize = true;
            this.LblRespuesta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblRespuesta.Location = new System.Drawing.Point(243, 117);
            this.LblRespuesta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblRespuesta.Name = "LblRespuesta";
            this.LblRespuesta.Size = new System.Drawing.Size(0, 20);
            this.LblRespuesta.TabIndex = 22;
            // 
            // TxtPantalla
            // 
            this.TxtPantalla.Location = new System.Drawing.Point(202, 86);
            this.TxtPantalla.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtPantalla.Name = "TxtPantalla";
            this.TxtPantalla.Size = new System.Drawing.Size(161, 20);
            this.TxtPantalla.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(163, 44);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(252, 22);
            this.label3.TabIndex = 24;
            this.label3.Text = "Aplicación de calculadora.";
            // 
            // BtnSalir
            // 
            this.BtnSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSalir.Location = new System.Drawing.Point(467, 368);
            this.BtnSalir.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Size = new System.Drawing.Size(74, 28);
            this.BtnSalir.TabIndex = 25;
            this.BtnSalir.Text = "Salir";
            this.BtnSalir.UseVisualStyleBackColor = false;
            this.BtnSalir.Click += new System.EventHandler(this.BtnSalir_Click);
            // 
            // BtnPunto
            // 
            this.BtnPunto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPunto.Location = new System.Drawing.Point(73, 311);
            this.BtnPunto.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnPunto.Name = "BtnPunto";
            this.BtnPunto.Size = new System.Drawing.Size(28, 30);
            this.BtnPunto.TabIndex = 26;
            this.BtnPunto.Text = ".";
            this.BtnPunto.UseVisualStyleBackColor = true;
            this.BtnPunto.Click += new System.EventHandler(this.BtnPunto_Click);
            // 
            // BtnLimpiar
            // 
            this.BtnLimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLimpiar.Location = new System.Drawing.Point(443, 244);
            this.BtnLimpiar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnLimpiar.Name = "BtnLimpiar";
            this.BtnLimpiar.Size = new System.Drawing.Size(70, 41);
            this.BtnLimpiar.TabIndex = 27;
            this.BtnLimpiar.Text = "Clear";
            this.BtnLimpiar.UseVisualStyleBackColor = true;
            this.BtnLimpiar.Click += new System.EventHandler(this.BtnLimpiar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 381);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 17);
            this.label2.TabIndex = 28;
            this.label2.Text = "@7364";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(552, 407);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnLimpiar);
            this.Controls.Add(this.BtnPunto);
            this.Controls.Add(this.BtnSalir);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TxtPantalla);
            this.Controls.Add(this.LblRespuesta);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnSeno);
            this.Controls.Add(this.BtnRaiz);
            this.Controls.Add(this.BtnLog);
            this.Controls.Add(this.BtnCos);
            this.Controls.Add(this.BtnTangente);
            this.Controls.Add(this.BtnPotencia);
            this.Controls.Add(this.BtnIgual);
            this.Controls.Add(this.BtnSuma);
            this.Controls.Add(this.Btn4);
            this.Controls.Add(this.Btn5);
            this.Controls.Add(this.Btn8);
            this.Controls.Add(this.Btn3);
            this.Controls.Add(this.Btn7);
            this.Controls.Add(this.Btn2);
            this.Controls.Add(this.Btn0);
            this.Controls.Add(this.BtnMultiplicacion);
            this.Controls.Add(this.BtnDivision);
            this.Controls.Add(this.Btn9);
            this.Controls.Add(this.BtnResta);
            this.Controls.Add(this.Btn6);
            this.Controls.Add(this.Btn1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.Button Btn6;
        private System.Windows.Forms.Button BtnResta;
        private System.Windows.Forms.Button Btn9;
        private System.Windows.Forms.Button BtnDivision;
        private System.Windows.Forms.Button BtnMultiplicacion;
        private System.Windows.Forms.Button Btn0;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button Btn7;
        private System.Windows.Forms.Button Btn3;
        private System.Windows.Forms.Button Btn8;
        private System.Windows.Forms.Button Btn5;
        private System.Windows.Forms.Button Btn4;
        private System.Windows.Forms.Button BtnSuma;
        private System.Windows.Forms.Button BtnIgual;
        private System.Windows.Forms.Button BtnPotencia;
        private System.Windows.Forms.Button BtnTangente;
        private System.Windows.Forms.Button BtnCos;
        private System.Windows.Forms.Button BtnLog;
        private System.Windows.Forms.Button BtnRaiz;
        private System.Windows.Forms.Button BtnSeno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LblRespuesta;
        private System.Windows.Forms.TextBox TxtPantalla;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BtnSalir;
        private System.Windows.Forms.Button BtnPunto;
        private System.Windows.Forms.Button BtnLimpiar;
        private System.Windows.Forms.Label label2;
    }
}

