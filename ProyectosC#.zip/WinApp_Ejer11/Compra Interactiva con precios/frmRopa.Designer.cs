﻿namespace Compra_Interactiva_con_precios
{
    partial class frmRopa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cbxChamarras = new System.Windows.Forms.ComboBox();
            this.cbxPants = new System.Windows.Forms.ComboBox();
            this.cbxTorso = new System.Windows.Forms.ComboBox();
            this.cbxZapatos = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblPrecioChamarra = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.ivaZaps = new System.Windows.Forms.Label();
            this.ivaTorso = new System.Windows.Forms.Label();
            this.ivaPants = new System.Windows.Forms.Label();
            this.ivaChamarra = new System.Windows.Forms.Label();
            this.lblPrecioZaps = new System.Windows.Forms.Label();
            this.lblPrecioTorso = new System.Windows.Forms.Label();
            this.lblPrecioPants = new System.Windows.Forms.Label();
            this.pbxPants = new System.Windows.Forms.PictureBox();
            this.pbxTorso = new System.Windows.Forms.PictureBox();
            this.pbxZapatos = new System.Windows.Forms.PictureBox();
            this.pbxChamarras = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.cantidadChamarras = new System.Windows.Forms.NumericUpDown();
            this.cantidadZaps = new System.Windows.Forms.NumericUpDown();
            this.cantidadTorso = new System.Windows.Forms.NumericUpDown();
            this.cantidadPants = new System.Windows.Forms.NumericUpDown();
            this.btnCalcularTotal = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.lblPrecioTotal = new System.Windows.Forms.Label();
            this.btnComprar = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPants)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTorso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxZapatos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamarras)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidadChamarras)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidadZaps)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidadTorso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidadPants)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(716, 58);
            this.panel1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(34, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ropa";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(381, 393);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 22);
            this.label2.TabIndex = 10;
            this.label2.Text = "Precio:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(197, 393);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 22);
            this.label3.TabIndex = 11;
            this.label3.Text = "Precio:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 392);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 22);
            this.label4.TabIndex = 12;
            this.label4.Text = "Precio:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(229, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 24);
            this.label6.TabIndex = 14;
            this.label6.Text = "Pantalones";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(421, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 24);
            this.label7.TabIndex = 15;
            this.label7.Text = "Torso";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(578, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 24);
            this.label8.TabIndex = 16;
            this.label8.Text = "Zapatos";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(36, 76);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(123, 24);
            this.label10.TabIndex = 18;
            this.label10.Text = "Chamarras";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(557, 393);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 22);
            this.label11.TabIndex = 19;
            this.label11.Text = "Precio:";
            // 
            // cbxChamarras
            // 
            this.cbxChamarras.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxChamarras.FormattingEnabled = true;
            this.cbxChamarras.Items.AddRange(new object[] {
            "Cuero",
            "Bomber (deportivas)",
            "Chaleco acolchado",
            "Biker",
            "Americana"});
            this.cbxChamarras.Location = new System.Drawing.Point(19, 114);
            this.cbxChamarras.Name = "cbxChamarras";
            this.cbxChamarras.Size = new System.Drawing.Size(151, 28);
            this.cbxChamarras.TabIndex = 25;
            this.cbxChamarras.SelectedIndexChanged += new System.EventHandler(this.cbxChamarras_SelectedIndexChanged);
            // 
            // cbxPants
            // 
            this.cbxPants.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxPants.FormattingEnabled = true;
            this.cbxPants.Items.AddRange(new object[] {
            "Jeans",
            "Cargo",
            "Deportivos",
            "De vestir"});
            this.cbxPants.Location = new System.Drawing.Point(201, 114);
            this.cbxPants.Name = "cbxPants";
            this.cbxPants.Size = new System.Drawing.Size(157, 28);
            this.cbxPants.TabIndex = 26;
            this.cbxPants.SelectedIndexChanged += new System.EventHandler(this.cbxPants_SelectedIndexChanged);
            // 
            // cbxTorso
            // 
            this.cbxTorso.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxTorso.FormattingEnabled = true;
            this.cbxTorso.Items.AddRange(new object[] {
            "Camisetas",
            "Camisa Polo",
            "Camisas de vestir",
            "Sudaderas",
            "Bividis",
            "Camisetas sin manga",
            "Jerseys"});
            this.cbxTorso.Location = new System.Drawing.Point(385, 114);
            this.cbxTorso.Name = "cbxTorso";
            this.cbxTorso.Size = new System.Drawing.Size(149, 28);
            this.cbxTorso.TabIndex = 27;
            this.cbxTorso.SelectedIndexChanged += new System.EventHandler(this.cbxTorso_SelectedIndexChanged);
            // 
            // cbxZapatos
            // 
            this.cbxZapatos.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxZapatos.FormattingEnabled = true;
            this.cbxZapatos.Items.AddRange(new object[] {
            "Jordan",
            "Zapatos de vestir",
            "Zapatillas",
            "Sandalias"});
            this.cbxZapatos.Location = new System.Drawing.Point(561, 114);
            this.cbxZapatos.Name = "cbxZapatos";
            this.cbxZapatos.Size = new System.Drawing.Size(142, 28);
            this.cbxZapatos.TabIndex = 28;
            this.cbxZapatos.SelectedIndexChanged += new System.EventHandler(this.cbxZapatos_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 421);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 22);
            this.label5.TabIndex = 29;
            this.label5.Text = "Con IVA:";
            // 
            // lblPrecioChamarra
            // 
            this.lblPrecioChamarra.AutoSize = true;
            this.lblPrecioChamarra.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioChamarra.Location = new System.Drawing.Point(88, 395);
            this.lblPrecioChamarra.Name = "lblPrecioChamarra";
            this.lblPrecioChamarra.Size = new System.Drawing.Size(0, 18);
            this.lblPrecioChamarra.TabIndex = 30;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(557, 422);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 22);
            this.label12.TabIndex = 31;
            this.label12.Text = "Con IVA:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(381, 422);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 22);
            this.label14.TabIndex = 33;
            this.label14.Text = "Con IVA:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(197, 422);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(90, 22);
            this.label15.TabIndex = 34;
            this.label15.Text = "Con IVA:";
            // 
            // ivaZaps
            // 
            this.ivaZaps.AutoSize = true;
            this.ivaZaps.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ivaZaps.Location = new System.Drawing.Point(644, 425);
            this.ivaZaps.Name = "ivaZaps";
            this.ivaZaps.Size = new System.Drawing.Size(0, 18);
            this.ivaZaps.TabIndex = 35;
            // 
            // ivaTorso
            // 
            this.ivaTorso.AutoSize = true;
            this.ivaTorso.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ivaTorso.Location = new System.Drawing.Point(466, 425);
            this.ivaTorso.Name = "ivaTorso";
            this.ivaTorso.Size = new System.Drawing.Size(0, 18);
            this.ivaTorso.TabIndex = 36;
            // 
            // ivaPants
            // 
            this.ivaPants.AutoSize = true;
            this.ivaPants.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ivaPants.Location = new System.Drawing.Point(284, 425);
            this.ivaPants.Name = "ivaPants";
            this.ivaPants.Size = new System.Drawing.Size(0, 18);
            this.ivaPants.TabIndex = 37;
            // 
            // ivaChamarra
            // 
            this.ivaChamarra.AutoSize = true;
            this.ivaChamarra.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ivaChamarra.Location = new System.Drawing.Point(101, 424);
            this.ivaChamarra.Name = "ivaChamarra";
            this.ivaChamarra.Size = new System.Drawing.Size(0, 18);
            this.ivaChamarra.TabIndex = 38;
            // 
            // lblPrecioZaps
            // 
            this.lblPrecioZaps.AutoSize = true;
            this.lblPrecioZaps.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioZaps.Location = new System.Drawing.Point(631, 396);
            this.lblPrecioZaps.Name = "lblPrecioZaps";
            this.lblPrecioZaps.Size = new System.Drawing.Size(0, 18);
            this.lblPrecioZaps.TabIndex = 39;
            // 
            // lblPrecioTorso
            // 
            this.lblPrecioTorso.AutoSize = true;
            this.lblPrecioTorso.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioTorso.Location = new System.Drawing.Point(454, 396);
            this.lblPrecioTorso.Name = "lblPrecioTorso";
            this.lblPrecioTorso.Size = new System.Drawing.Size(0, 18);
            this.lblPrecioTorso.TabIndex = 40;
            // 
            // lblPrecioPants
            // 
            this.lblPrecioPants.AutoSize = true;
            this.lblPrecioPants.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioPants.Location = new System.Drawing.Point(270, 396);
            this.lblPrecioPants.Name = "lblPrecioPants";
            this.lblPrecioPants.Size = new System.Drawing.Size(0, 18);
            this.lblPrecioPants.TabIndex = 41;
            // 
            // pbxPants
            // 
            this.pbxPants.Location = new System.Drawing.Point(201, 172);
            this.pbxPants.Name = "pbxPants";
            this.pbxPants.Size = new System.Drawing.Size(157, 204);
            this.pbxPants.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxPants.TabIndex = 23;
            this.pbxPants.TabStop = false;
            // 
            // pbxTorso
            // 
            this.pbxTorso.Location = new System.Drawing.Point(385, 172);
            this.pbxTorso.Name = "pbxTorso";
            this.pbxTorso.Size = new System.Drawing.Size(149, 204);
            this.pbxTorso.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxTorso.TabIndex = 22;
            this.pbxTorso.TabStop = false;
            // 
            // pbxZapatos
            // 
            this.pbxZapatos.Location = new System.Drawing.Point(561, 172);
            this.pbxZapatos.Name = "pbxZapatos";
            this.pbxZapatos.Size = new System.Drawing.Size(142, 204);
            this.pbxZapatos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxZapatos.TabIndex = 21;
            this.pbxZapatos.TabStop = false;
            // 
            // pbxChamarras
            // 
            this.pbxChamarras.Location = new System.Drawing.Point(19, 172);
            this.pbxChamarras.Name = "pbxChamarras";
            this.pbxChamarras.Size = new System.Drawing.Size(151, 204);
            this.pbxChamarras.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxChamarras.TabIndex = 20;
            this.pbxChamarras.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(13, 449);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 14);
            this.label9.TabIndex = 46;
            this.label9.Text = "Cantidad:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(195, 449);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(58, 14);
            this.label13.TabIndex = 47;
            this.label13.Text = "Cantidad:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(379, 449);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 14);
            this.label16.TabIndex = 48;
            this.label16.Text = "Cantidad:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(555, 449);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(58, 14);
            this.label17.TabIndex = 49;
            this.label17.Text = "Cantidad:";
            // 
            // cantidadChamarras
            // 
            this.cantidadChamarras.Location = new System.Drawing.Point(69, 447);
            this.cantidadChamarras.Name = "cantidadChamarras";
            this.cantidadChamarras.Size = new System.Drawing.Size(33, 20);
            this.cantidadChamarras.TabIndex = 50;
            // 
            // cantidadZaps
            // 
            this.cantidadZaps.Location = new System.Drawing.Point(611, 447);
            this.cantidadZaps.Name = "cantidadZaps";
            this.cantidadZaps.Size = new System.Drawing.Size(33, 20);
            this.cantidadZaps.TabIndex = 51;
            // 
            // cantidadTorso
            // 
            this.cantidadTorso.Location = new System.Drawing.Point(435, 447);
            this.cantidadTorso.Name = "cantidadTorso";
            this.cantidadTorso.Size = new System.Drawing.Size(33, 20);
            this.cantidadTorso.TabIndex = 52;
            // 
            // cantidadPants
            // 
            this.cantidadPants.Location = new System.Drawing.Point(251, 447);
            this.cantidadPants.Name = "cantidadPants";
            this.cantidadPants.Size = new System.Drawing.Size(33, 20);
            this.cantidadPants.TabIndex = 53;
            // 
            // btnCalcularTotal
            // 
            this.btnCalcularTotal.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcularTotal.Location = new System.Drawing.Point(19, 482);
            this.btnCalcularTotal.Name = "btnCalcularTotal";
            this.btnCalcularTotal.Size = new System.Drawing.Size(137, 28);
            this.btnCalcularTotal.TabIndex = 55;
            this.btnCalcularTotal.Text = "Calcular el total ";
            this.btnCalcularTotal.UseVisualStyleBackColor = true;
            this.btnCalcularTotal.Click += new System.EventHandler(this.btnCalcularTotal_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(16, 527);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(68, 24);
            this.label18.TabIndex = 56;
            this.label18.Text = "Total:";
            // 
            // lblPrecioTotal
            // 
            this.lblPrecioTotal.AutoSize = true;
            this.lblPrecioTotal.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioTotal.Location = new System.Drawing.Point(87, 529);
            this.lblPrecioTotal.Name = "lblPrecioTotal";
            this.lblPrecioTotal.Size = new System.Drawing.Size(0, 22);
            this.lblPrecioTotal.TabIndex = 57;
            // 
            // btnComprar
            // 
            this.btnComprar.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComprar.Location = new System.Drawing.Point(287, 482);
            this.btnComprar.Name = "btnComprar";
            this.btnComprar.Size = new System.Drawing.Size(122, 39);
            this.btnComprar.TabIndex = 58;
            this.btnComprar.Text = "Comprar";
            this.btnComprar.UseVisualStyleBackColor = true;
            this.btnComprar.Click += new System.EventHandler(this.btnComprar_Click);
            // 
            // frmRopa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(734, 441);
            this.Controls.Add(this.btnComprar);
            this.Controls.Add(this.lblPrecioTotal);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.btnCalcularTotal);
            this.Controls.Add(this.cantidadPants);
            this.Controls.Add(this.cantidadTorso);
            this.Controls.Add(this.cantidadZaps);
            this.Controls.Add(this.cantidadChamarras);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblPrecioPants);
            this.Controls.Add(this.lblPrecioTorso);
            this.Controls.Add(this.lblPrecioZaps);
            this.Controls.Add(this.ivaChamarra);
            this.Controls.Add(this.ivaPants);
            this.Controls.Add(this.ivaTorso);
            this.Controls.Add(this.ivaZaps);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lblPrecioChamarra);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbxZapatos);
            this.Controls.Add(this.cbxTorso);
            this.Controls.Add(this.cbxPants);
            this.Controls.Add(this.cbxChamarras);
            this.Controls.Add(this.pbxPants);
            this.Controls.Add(this.pbxTorso);
            this.Controls.Add(this.pbxZapatos);
            this.Controls.Add(this.pbxChamarras);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "frmRopa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ropa";
            this.Shown += new System.EventHandler(this.frmRopa_Shown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPants)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTorso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxZapatos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxChamarras)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidadChamarras)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidadZaps)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidadTorso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cantidadPants)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pbxChamarras;
        private System.Windows.Forms.PictureBox pbxZapatos;
        private System.Windows.Forms.PictureBox pbxTorso;
        private System.Windows.Forms.PictureBox pbxPants;
        private System.Windows.Forms.ComboBox cbxChamarras;
        private System.Windows.Forms.ComboBox cbxPants;
        private System.Windows.Forms.ComboBox cbxTorso;
        private System.Windows.Forms.ComboBox cbxZapatos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblPrecioChamarra;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label ivaZaps;
        private System.Windows.Forms.Label ivaTorso;
        private System.Windows.Forms.Label ivaPants;
        private System.Windows.Forms.Label ivaChamarra;
        private System.Windows.Forms.Label lblPrecioZaps;
        private System.Windows.Forms.Label lblPrecioTorso;
        private System.Windows.Forms.Label lblPrecioPants;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown cantidadChamarras;
        private System.Windows.Forms.NumericUpDown cantidadZaps;
        private System.Windows.Forms.NumericUpDown cantidadTorso;
        private System.Windows.Forms.NumericUpDown cantidadPants;
        private System.Windows.Forms.Button btnCalcularTotal;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblPrecioTotal;
        private System.Windows.Forms.Button btnComprar;
    }
}