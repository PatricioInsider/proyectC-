﻿namespace Compra_Interactiva_con_precios
{
    partial class formInicioCompraInt
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnVerRopa = new System.Windows.Forms.Button();
            this.btnVerVehiculos = new System.Windows.Forms.Button();
            this.btnVerTech = new System.Windows.Forms.Button();
            this.btnCarrito = new System.Windows.Forms.Button();
            this.pbxTech3 = new System.Windows.Forms.PictureBox();
            this.pbxTech2 = new System.Windows.Forms.PictureBox();
            this.pbxVehiculos = new System.Windows.Forms.PictureBox();
            this.pbxTech1 = new System.Windows.Forms.PictureBox();
            this.pbxRopa = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTech3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTech2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVehiculos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTech1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRopa)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(223, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Compra Lucas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(275, 78);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ménu Principal";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(85, 129);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ropa";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(286, 129);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 22);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tecnología";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(530, 129);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 22);
            this.label6.TabIndex = 5;
            this.label6.Text = "Vehículos";
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnSalir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalir.ForeColor = System.Drawing.Color.White;
            this.btnSalir.Location = new System.Drawing.Point(626, 13);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(77, 34);
            this.btnSalir.TabIndex = 7;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnSalir);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(716, 67);
            this.panel1.TabIndex = 8;
            // 
            // btnVerRopa
            // 
            this.btnVerRopa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnVerRopa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerRopa.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerRopa.ForeColor = System.Drawing.Color.White;
            this.btnVerRopa.Location = new System.Drawing.Point(89, 415);
            this.btnVerRopa.Name = "btnVerRopa";
            this.btnVerRopa.Size = new System.Drawing.Size(63, 26);
            this.btnVerRopa.TabIndex = 16;
            this.btnVerRopa.Text = "Ver";
            this.btnVerRopa.UseVisualStyleBackColor = false;
            this.btnVerRopa.Click += new System.EventHandler(this.btnVerRopa_Click);
            this.btnVerRopa.MouseEnter += new System.EventHandler(this.btnVerRopa_MouseEnter);
            // 
            // btnVerVehiculos
            // 
            this.btnVerVehiculos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnVerVehiculos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerVehiculos.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerVehiculos.ForeColor = System.Drawing.Color.White;
            this.btnVerVehiculos.Location = new System.Drawing.Point(561, 415);
            this.btnVerVehiculos.Name = "btnVerVehiculos";
            this.btnVerVehiculos.Size = new System.Drawing.Size(63, 26);
            this.btnVerVehiculos.TabIndex = 18;
            this.btnVerVehiculos.Text = "Ver";
            this.btnVerVehiculos.UseVisualStyleBackColor = false;
            this.btnVerVehiculos.Click += new System.EventHandler(this.btnVerVehiculos_Click);
            // 
            // btnVerTech
            // 
            this.btnVerTech.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnVerTech.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerTech.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerTech.ForeColor = System.Drawing.Color.White;
            this.btnVerTech.Location = new System.Drawing.Point(317, 417);
            this.btnVerTech.Name = "btnVerTech";
            this.btnVerTech.Size = new System.Drawing.Size(63, 26);
            this.btnVerTech.TabIndex = 20;
            this.btnVerTech.Text = "Ver";
            this.btnVerTech.UseVisualStyleBackColor = false;
            // 
            // btnCarrito
            // 
            this.btnCarrito.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCarrito.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCarrito.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCarrito.ForeColor = System.Drawing.Color.White;
            this.btnCarrito.Location = new System.Drawing.Point(615, 78);
            this.btnCarrito.Name = "btnCarrito";
            this.btnCarrito.Size = new System.Drawing.Size(88, 32);
            this.btnCarrito.TabIndex = 21;
            this.btnCarrito.Text = "Carrito";
            this.btnCarrito.UseVisualStyleBackColor = false;
            this.btnCarrito.Click += new System.EventHandler(this.button1_Click);
            // 
            // pbxTech3
            // 
            this.pbxTech3.Image = global::Compra_Interactiva_con_precios.Properties.Resources.los_mejores_celulares_android_con_memoria_ampliable_022;
            this.pbxTech3.Location = new System.Drawing.Point(259, 318);
            this.pbxTech3.Name = "pbxTech3";
            this.pbxTech3.Size = new System.Drawing.Size(166, 93);
            this.pbxTech3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxTech3.TabIndex = 15;
            this.pbxTech3.TabStop = false;
            // 
            // pbxTech2
            // 
            this.pbxTech2.Image = global::Compra_Interactiva_con_precios.Properties.Resources.laptops;
            this.pbxTech2.Location = new System.Drawing.Point(259, 234);
            this.pbxTech2.Name = "pbxTech2";
            this.pbxTech2.Size = new System.Drawing.Size(166, 121);
            this.pbxTech2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxTech2.TabIndex = 12;
            this.pbxTech2.TabStop = false;
            // 
            // pbxVehiculos
            // 
            this.pbxVehiculos.Image = global::Compra_Interactiva_con_precios.Properties.Resources.vehiculos;
            this.pbxVehiculos.Location = new System.Drawing.Point(464, 161);
            this.pbxVehiculos.Name = "pbxVehiculos";
            this.pbxVehiculos.Size = new System.Drawing.Size(239, 248);
            this.pbxVehiculos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxVehiculos.TabIndex = 11;
            this.pbxVehiculos.TabStop = false;
            // 
            // pbxTech1
            // 
            this.pbxTech1.Image = global::Compra_Interactiva_con_precios.Properties.Resources.tech1;
            this.pbxTech1.Location = new System.Drawing.Point(259, 161);
            this.pbxTech1.Name = "pbxTech1";
            this.pbxTech1.Size = new System.Drawing.Size(166, 110);
            this.pbxTech1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxTech1.TabIndex = 10;
            this.pbxTech1.TabStop = false;
            // 
            // pbxRopa
            // 
            this.pbxRopa.Image = global::Compra_Interactiva_con_precios.Properties.Resources.ropa;
            this.pbxRopa.Location = new System.Drawing.Point(12, 168);
            this.pbxRopa.Name = "pbxRopa";
            this.pbxRopa.Size = new System.Drawing.Size(215, 241);
            this.pbxRopa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxRopa.TabIndex = 9;
            this.pbxRopa.TabStop = false;
            // 
            // formInicioCompraInt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(715, 453);
            this.Controls.Add(this.btnCarrito);
            this.Controls.Add(this.btnVerTech);
            this.Controls.Add(this.btnVerVehiculos);
            this.Controls.Add(this.btnVerRopa);
            this.Controls.Add(this.pbxTech3);
            this.Controls.Add(this.pbxTech2);
            this.Controls.Add(this.pbxVehiculos);
            this.Controls.Add(this.pbxTech1);
            this.Controls.Add(this.pbxRopa);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "formInicioCompraInt";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inicio";
            this.Load += new System.EventHandler(this.formInicioCompraInt_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTech3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTech2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVehiculos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxTech1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRopa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbxRopa;
        private System.Windows.Forms.PictureBox pbxTech1;
        private System.Windows.Forms.PictureBox pbxVehiculos;
        private System.Windows.Forms.PictureBox pbxTech2;
        private System.Windows.Forms.PictureBox pbxTech3;
        private System.Windows.Forms.Button btnVerRopa;
        private System.Windows.Forms.Button btnVerVehiculos;
        private System.Windows.Forms.Button btnVerTech;
        private System.Windows.Forms.Button btnCarrito;
    }
}

