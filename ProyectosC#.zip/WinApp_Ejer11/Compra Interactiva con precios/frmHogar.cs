﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Compra_Interactiva_con_precios
{
    public partial class frmHogar : Form
    {
        public frmHogar()
        {
            InitializeComponent();
        }
    }
}
