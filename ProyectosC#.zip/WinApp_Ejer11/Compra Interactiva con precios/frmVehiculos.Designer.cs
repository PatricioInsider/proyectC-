﻿namespace Compra_Interactiva_con_precios
{
    partial class frmVehiculos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rbtnChery = new System.Windows.Forms.RadioButton();
            this.rbtnGroove = new System.Windows.Forms.RadioButton();
            this.rbtnLambo = new System.Windows.Forms.RadioButton();
            this.rbtnCeratoR = new System.Windows.Forms.RadioButton();
            this.rbtnMaserati = new System.Windows.Forms.RadioButton();
            this.rbtnFerrari = new System.Windows.Forms.RadioButton();
            this.rbtnFactory = new System.Windows.Forms.RadioButton();
            this.rbtnFord = new System.Windows.Forms.RadioButton();
            this.rbtnShineray = new System.Windows.Forms.RadioButton();
            this.rbtnDY = new System.Windows.Forms.RadioButton();
            this.rbtnToyota = new System.Windows.Forms.RadioButton();
            this.rbtnJeep = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblIva4x4 = new System.Windows.Forms.Label();
            this.lblPrecio4x4 = new System.Windows.Forms.Label();
            this.lblPrecioMotos = new System.Windows.Forms.Label();
            this.lblIvaMotos = new System.Windows.Forms.Label();
            this.lblIvaFami = new System.Windows.Forms.Label();
            this.lblPrecioFami = new System.Windows.Forms.Label();
            this.lblIvaDeportivos = new System.Windows.Forms.Label();
            this.lblPrecioDeportivos = new System.Windows.Forms.Label();
            this.pboxFamiliares = new System.Windows.Forms.PictureBox();
            this.pboxMotos = new System.Windows.Forms.PictureBox();
            this.pbox4x4 = new System.Windows.Forms.PictureBox();
            this.pboxDeportivos = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.lblTotalVehiculos = new System.Windows.Forms.Label();
            this.btnCalcularTotal = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pboxFamiliares)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxMotos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox4x4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxDeportivos)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(15, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vehículos";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(713, 53);
            this.panel1.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 79);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 24);
            this.label3.TabIndex = 13;
            this.label3.Text = "Deportivos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(550, 82);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 24);
            this.label4.TabIndex = 14;
            this.label4.Text = "4x4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(376, 82);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 24);
            this.label5.TabIndex = 15;
            this.label5.Text = "Motos";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(191, 79);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 24);
            this.label6.TabIndex = 16;
            this.label6.Text = "Familiares";
            // 
            // rbtnChery
            // 
            this.rbtnChery.AutoSize = true;
            this.rbtnChery.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnChery.Location = new System.Drawing.Point(195, 109);
            this.rbtnChery.Name = "rbtnChery";
            this.rbtnChery.Size = new System.Drawing.Size(127, 21);
            this.rbtnChery.TabIndex = 17;
            this.rbtnChery.TabStop = true;
            this.rbtnChery.Text = "Chery TIGGO 8";
            this.rbtnChery.UseVisualStyleBackColor = true;
            this.rbtnChery.CheckedChanged += new System.EventHandler(this.rbtnChery_CheckedChanged);
            // 
            // rbtnGroove
            // 
            this.rbtnGroove.AutoSize = true;
            this.rbtnGroove.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnGroove.Location = new System.Drawing.Point(195, 137);
            this.rbtnGroove.Name = "rbtnGroove";
            this.rbtnGroove.Size = new System.Drawing.Size(157, 21);
            this.rbtnGroove.TabIndex = 18;
            this.rbtnGroove.TabStop = true;
            this.rbtnGroove.Text = "Chevrolet GROOVE";
            this.rbtnGroove.UseVisualStyleBackColor = true;
            this.rbtnGroove.CheckedChanged += new System.EventHandler(this.rbtnGroove_CheckedChanged);
            // 
            // rbtnLambo
            // 
            this.rbtnLambo.AutoSize = true;
            this.rbtnLambo.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnLambo.Location = new System.Drawing.Point(21, 109);
            this.rbtnLambo.Name = "rbtnLambo";
            this.rbtnLambo.Size = new System.Drawing.Size(110, 21);
            this.rbtnLambo.TabIndex = 19;
            this.rbtnLambo.TabStop = true;
            this.rbtnLambo.Text = "Lamborghini ";
            this.rbtnLambo.UseVisualStyleBackColor = true;
            this.rbtnLambo.CheckedChanged += new System.EventHandler(this.rbtnLambo_CheckedChanged);
            // 
            // rbtnCeratoR
            // 
            this.rbtnCeratoR.AutoSize = true;
            this.rbtnCeratoR.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnCeratoR.Location = new System.Drawing.Point(195, 165);
            this.rbtnCeratoR.Name = "rbtnCeratoR";
            this.rbtnCeratoR.Size = new System.Drawing.Size(110, 21);
            this.rbtnCeratoR.TabIndex = 20;
            this.rbtnCeratoR.TabStop = true;
            this.rbtnCeratoR.Text = "Kia Cerato R";
            this.rbtnCeratoR.UseVisualStyleBackColor = true;
            this.rbtnCeratoR.CheckedChanged += new System.EventHandler(this.rbtnCeratoR_CheckedChanged);
            // 
            // rbtnMaserati
            // 
            this.rbtnMaserati.AutoSize = true;
            this.rbtnMaserati.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnMaserati.Location = new System.Drawing.Point(21, 161);
            this.rbtnMaserati.Name = "rbtnMaserati";
            this.rbtnMaserati.Size = new System.Drawing.Size(109, 21);
            this.rbtnMaserati.TabIndex = 21;
            this.rbtnMaserati.TabStop = true;
            this.rbtnMaserati.Text = "Maseratti GT";
            this.rbtnMaserati.UseVisualStyleBackColor = true;
            this.rbtnMaserati.CheckedChanged += new System.EventHandler(this.rbtnMaserati_CheckedChanged);
            // 
            // rbtnFerrari
            // 
            this.rbtnFerrari.AutoSize = true;
            this.rbtnFerrari.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnFerrari.Location = new System.Drawing.Point(21, 133);
            this.rbtnFerrari.Name = "rbtnFerrari";
            this.rbtnFerrari.Size = new System.Drawing.Size(69, 21);
            this.rbtnFerrari.TabIndex = 22;
            this.rbtnFerrari.TabStop = true;
            this.rbtnFerrari.Text = "Ferrari";
            this.rbtnFerrari.UseVisualStyleBackColor = true;
            this.rbtnFerrari.CheckedChanged += new System.EventHandler(this.rbtnFerrari_CheckedChanged);
            // 
            // rbtnFactory
            // 
            this.rbtnFactory.AutoSize = true;
            this.rbtnFactory.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnFactory.Location = new System.Drawing.Point(380, 109);
            this.rbtnFactory.Name = "rbtnFactory";
            this.rbtnFactory.Size = new System.Drawing.Size(143, 21);
            this.rbtnFactory.TabIndex = 23;
            this.rbtnFactory.TabStop = true;
            this.rbtnFactory.Text = "Factory Bike 2024";
            this.rbtnFactory.UseVisualStyleBackColor = true;
            this.rbtnFactory.CheckedChanged += new System.EventHandler(this.rbtnFactory_CheckedChanged);
            // 
            // rbtnFord
            // 
            this.rbtnFord.AutoSize = true;
            this.rbtnFord.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnFord.Location = new System.Drawing.Point(554, 109);
            this.rbtnFord.Name = "rbtnFord";
            this.rbtnFord.Size = new System.Drawing.Size(130, 21);
            this.rbtnFord.TabIndex = 24;
            this.rbtnFord.TabStop = true;
            this.rbtnFord.Text = "Ford Edge 2013";
            this.rbtnFord.UseVisualStyleBackColor = true;
            this.rbtnFord.CheckedChanged += new System.EventHandler(this.rbtnFord_CheckedChanged);
            // 
            // rbtnShineray
            // 
            this.rbtnShineray.AutoSize = true;
            this.rbtnShineray.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnShineray.Location = new System.Drawing.Point(380, 165);
            this.rbtnShineray.Name = "rbtnShineray";
            this.rbtnShineray.Size = new System.Drawing.Size(177, 21);
            this.rbtnShineray.TabIndex = 25;
            this.rbtnShineray.TabStop = true;
            this.rbtnShineray.Text = "Shineray CHIEFF II 250";
            this.rbtnShineray.UseVisualStyleBackColor = true;
            this.rbtnShineray.CheckedChanged += new System.EventHandler(this.rbtnShineray_CheckedChanged);
            // 
            // rbtnDY
            // 
            this.rbtnDY.AutoSize = true;
            this.rbtnDY.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnDY.Location = new System.Drawing.Point(380, 137);
            this.rbtnDY.Name = "rbtnDY";
            this.rbtnDY.Size = new System.Drawing.Size(168, 21);
            this.rbtnDY.TabIndex = 26;
            this.rbtnDY.TabStop = true;
            this.rbtnDY.Text = "Daytona DY 300 2024";
            this.rbtnDY.UseVisualStyleBackColor = true;
            this.rbtnDY.CheckedChanged += new System.EventHandler(this.rbtnDY_CheckedChanged);
            // 
            // rbtnToyota
            // 
            this.rbtnToyota.AutoSize = true;
            this.rbtnToyota.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnToyota.Location = new System.Drawing.Point(554, 137);
            this.rbtnToyota.Name = "rbtnToyota";
            this.rbtnToyota.Size = new System.Drawing.Size(151, 21);
            this.rbtnToyota.TabIndex = 27;
            this.rbtnToyota.TabStop = true;
            this.rbtnToyota.Text = "Toyota Fortuner 2.7";
            this.rbtnToyota.UseVisualStyleBackColor = true;
            this.rbtnToyota.CheckedChanged += new System.EventHandler(this.rbtnToyota_CheckedChanged);
            // 
            // rbtnJeep
            // 
            this.rbtnJeep.AutoSize = true;
            this.rbtnJeep.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnJeep.Location = new System.Drawing.Point(554, 165);
            this.rbtnJeep.Name = "rbtnJeep";
            this.rbtnJeep.Size = new System.Drawing.Size(157, 21);
            this.rbtnJeep.TabIndex = 28;
            this.rbtnJeep.TabStop = true;
            this.rbtnJeep.Text = "Jeep Wrangler 2018";
            this.rbtnJeep.UseVisualStyleBackColor = true;
            this.rbtnJeep.CheckedChanged += new System.EventHandler(this.rbtnJeep_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(551, 437);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 19);
            this.label2.TabIndex = 33;
            this.label2.Text = "Con IVA:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(551, 407);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 19);
            this.label7.TabIndex = 34;
            this.label7.Text = "Precio:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(377, 437);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 19);
            this.label8.TabIndex = 35;
            this.label8.Text = "Con IVA:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(377, 407);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 19);
            this.label9.TabIndex = 36;
            this.label9.Text = "Precio:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(192, 437);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 19);
            this.label10.TabIndex = 37;
            this.label10.Text = "Con IVA:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(192, 407);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 19);
            this.label11.TabIndex = 38;
            this.label11.Text = "Precio:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(18, 437);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 19);
            this.label12.TabIndex = 39;
            this.label12.Text = "Con IVA:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(18, 407);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 19);
            this.label13.TabIndex = 40;
            this.label13.Text = "Precio:";
            // 
            // lblIva4x4
            // 
            this.lblIva4x4.AutoSize = true;
            this.lblIva4x4.Location = new System.Drawing.Point(619, 437);
            this.lblIva4x4.Name = "lblIva4x4";
            this.lblIva4x4.Size = new System.Drawing.Size(0, 18);
            this.lblIva4x4.TabIndex = 41;
            // 
            // lblPrecio4x4
            // 
            this.lblPrecio4x4.AutoSize = true;
            this.lblPrecio4x4.Location = new System.Drawing.Point(618, 407);
            this.lblPrecio4x4.Name = "lblPrecio4x4";
            this.lblPrecio4x4.Size = new System.Drawing.Size(0, 18);
            this.lblPrecio4x4.TabIndex = 42;
            // 
            // lblPrecioMotos
            // 
            this.lblPrecioMotos.AutoSize = true;
            this.lblPrecioMotos.Location = new System.Drawing.Point(445, 407);
            this.lblPrecioMotos.Name = "lblPrecioMotos";
            this.lblPrecioMotos.Size = new System.Drawing.Size(0, 18);
            this.lblPrecioMotos.TabIndex = 43;
            // 
            // lblIvaMotos
            // 
            this.lblIvaMotos.AutoSize = true;
            this.lblIvaMotos.Location = new System.Drawing.Point(445, 437);
            this.lblIvaMotos.Name = "lblIvaMotos";
            this.lblIvaMotos.Size = new System.Drawing.Size(0, 18);
            this.lblIvaMotos.TabIndex = 44;
            // 
            // lblIvaFami
            // 
            this.lblIvaFami.AutoSize = true;
            this.lblIvaFami.Location = new System.Drawing.Point(256, 437);
            this.lblIvaFami.Name = "lblIvaFami";
            this.lblIvaFami.Size = new System.Drawing.Size(0, 18);
            this.lblIvaFami.TabIndex = 45;
            // 
            // lblPrecioFami
            // 
            this.lblPrecioFami.AutoSize = true;
            this.lblPrecioFami.Location = new System.Drawing.Point(256, 407);
            this.lblPrecioFami.Name = "lblPrecioFami";
            this.lblPrecioFami.Size = new System.Drawing.Size(0, 18);
            this.lblPrecioFami.TabIndex = 46;
            // 
            // lblIvaDeportivos
            // 
            this.lblIvaDeportivos.AutoSize = true;
            this.lblIvaDeportivos.Location = new System.Drawing.Point(83, 437);
            this.lblIvaDeportivos.Name = "lblIvaDeportivos";
            this.lblIvaDeportivos.Size = new System.Drawing.Size(0, 18);
            this.lblIvaDeportivos.TabIndex = 47;
            // 
            // lblPrecioDeportivos
            // 
            this.lblPrecioDeportivos.AutoSize = true;
            this.lblPrecioDeportivos.Location = new System.Drawing.Point(83, 407);
            this.lblPrecioDeportivos.Name = "lblPrecioDeportivos";
            this.lblPrecioDeportivos.Size = new System.Drawing.Size(0, 18);
            this.lblPrecioDeportivos.TabIndex = 48;
            // 
            // pboxFamiliares
            // 
            this.pboxFamiliares.Location = new System.Drawing.Point(195, 189);
            this.pboxFamiliares.Name = "pboxFamiliares";
            this.pboxFamiliares.Size = new System.Drawing.Size(136, 201);
            this.pboxFamiliares.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pboxFamiliares.TabIndex = 32;
            this.pboxFamiliares.TabStop = false;
            // 
            // pboxMotos
            // 
            this.pboxMotos.Location = new System.Drawing.Point(380, 189);
            this.pboxMotos.Name = "pboxMotos";
            this.pboxMotos.Size = new System.Drawing.Size(136, 201);
            this.pboxMotos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pboxMotos.TabIndex = 31;
            this.pboxMotos.TabStop = false;
            // 
            // pbox4x4
            // 
            this.pbox4x4.Location = new System.Drawing.Point(554, 189);
            this.pbox4x4.Name = "pbox4x4";
            this.pbox4x4.Size = new System.Drawing.Size(136, 201);
            this.pbox4x4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox4x4.TabIndex = 30;
            this.pbox4x4.TabStop = false;
            // 
            // pboxDeportivos
            // 
            this.pboxDeportivos.Location = new System.Drawing.Point(21, 189);
            this.pboxDeportivos.Name = "pboxDeportivos";
            this.pboxDeportivos.Size = new System.Drawing.Size(136, 201);
            this.pboxDeportivos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pboxDeportivos.TabIndex = 29;
            this.pboxDeportivos.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(294, 468);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 32);
            this.button1.TabIndex = 49;
            this.button1.Text = "Comprar";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(19, 514);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 22);
            this.label14.TabIndex = 50;
            this.label14.Text = "Total:";
            // 
            // lblTotalVehiculos
            // 
            this.lblTotalVehiculos.AutoSize = true;
            this.lblTotalVehiculos.Location = new System.Drawing.Point(79, 517);
            this.lblTotalVehiculos.Name = "lblTotalVehiculos";
            this.lblTotalVehiculos.Size = new System.Drawing.Size(0, 18);
            this.lblTotalVehiculos.TabIndex = 51;
            // 
            // btnCalcularTotal
            // 
            this.btnCalcularTotal.Location = new System.Drawing.Point(22, 472);
            this.btnCalcularTotal.Name = "btnCalcularTotal";
            this.btnCalcularTotal.Size = new System.Drawing.Size(143, 26);
            this.btnCalcularTotal.TabIndex = 52;
            this.btnCalcularTotal.Text = "Calcular el total";
            this.btnCalcularTotal.UseVisualStyleBackColor = true;
            this.btnCalcularTotal.Click += new System.EventHandler(this.btnCalcularTotal_Click_1);
            // 
            // frmVehiculos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(735, 489);
            this.Controls.Add(this.btnCalcularTotal);
            this.Controls.Add(this.lblTotalVehiculos);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblPrecioDeportivos);
            this.Controls.Add(this.lblIvaDeportivos);
            this.Controls.Add(this.lblPrecioFami);
            this.Controls.Add(this.lblIvaFami);
            this.Controls.Add(this.lblIvaMotos);
            this.Controls.Add(this.lblPrecioMotos);
            this.Controls.Add(this.lblPrecio4x4);
            this.Controls.Add(this.lblIva4x4);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pboxFamiliares);
            this.Controls.Add(this.pboxMotos);
            this.Controls.Add(this.pbox4x4);
            this.Controls.Add(this.pboxDeportivos);
            this.Controls.Add(this.rbtnJeep);
            this.Controls.Add(this.rbtnToyota);
            this.Controls.Add(this.rbtnDY);
            this.Controls.Add(this.rbtnShineray);
            this.Controls.Add(this.rbtnFord);
            this.Controls.Add(this.rbtnFactory);
            this.Controls.Add(this.rbtnFerrari);
            this.Controls.Add(this.rbtnMaserati);
            this.Controls.Add(this.rbtnCeratoR);
            this.Controls.Add(this.rbtnLambo);
            this.Controls.Add(this.rbtnGroove);
            this.Controls.Add(this.rbtnChery);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmVehiculos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmVehiculos";
            this.Shown += new System.EventHandler(this.frmVehiculos_Shown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pboxFamiliares)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxMotos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox4x4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pboxDeportivos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rbtnChery;
        private System.Windows.Forms.RadioButton rbtnGroove;
        private System.Windows.Forms.RadioButton rbtnLambo;
        private System.Windows.Forms.RadioButton rbtnCeratoR;
        private System.Windows.Forms.RadioButton rbtnMaserati;
        private System.Windows.Forms.RadioButton rbtnFerrari;
        private System.Windows.Forms.RadioButton rbtnFactory;
        private System.Windows.Forms.RadioButton rbtnFord;
        private System.Windows.Forms.RadioButton rbtnShineray;
        private System.Windows.Forms.RadioButton rbtnDY;
        private System.Windows.Forms.RadioButton rbtnToyota;
        private System.Windows.Forms.RadioButton rbtnJeep;
        private System.Windows.Forms.PictureBox pboxDeportivos;
        private System.Windows.Forms.PictureBox pbox4x4;
        private System.Windows.Forms.PictureBox pboxMotos;
        private System.Windows.Forms.PictureBox pboxFamiliares;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblIva4x4;
        private System.Windows.Forms.Label lblPrecio4x4;
        private System.Windows.Forms.Label lblPrecioMotos;
        private System.Windows.Forms.Label lblIvaMotos;
        private System.Windows.Forms.Label lblIvaFami;
        private System.Windows.Forms.Label lblPrecioFami;
        private System.Windows.Forms.Label lblIvaDeportivos;
        private System.Windows.Forms.Label lblPrecioDeportivos;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblTotalVehiculos;
        private System.Windows.Forms.Button btnCalcularTotal;
    }
}